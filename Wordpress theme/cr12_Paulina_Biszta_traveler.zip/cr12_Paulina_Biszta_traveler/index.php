<?php get_header(); ?>
<div class="container-fluid m-0 p-0">
        
<div class="jumbotron">
  <h1 class="display-4">Hello, Traveler!</h1>
  <p class="lead">You are in a good place.</p>
</div>
</div>
   
<div class="container-fluid">
      <div id="ttr_main" class="row">
         <div id="ttr_content" class="col-lg-9 col-sm-12 col-md-9 col-xs-12">
            <div class="row">
              
                  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                  <div class="col-lg-6 col-sm-12 col-md-12 col-xs-12"> 
                  <div class="card p-3 m-1">
                 
                  <?php if(has_post_thumbnail()) : ?>
                  <?php the_post_thumbnail('medium_large'); ?>
                  <?php endif; ?>
                  <div class="row justify-content-between m-0">
                     <h5><?php the_category(); ?></h5>
                     <h6>Posted on <?php the_time('F jS, Y') ?></h6>
                 
                  </div>
                  <hr>
                  <h3 class="text-center"><?php the_title(); ?></h3>
                  <p><?php the_excerpt();?></p>
                  <a class="btn btn-outline-primary" href="<?php the_permalink(); ?>">More...</a>
                  </div>
              </div>
               <?php endwhile; else: ?> 
               <p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
               <?php endif; ?>
            </div>
         </div>
       
             <div id="sidebar" class="col-lg-3 col-md-3 col-sm-12 col-xs-12 pt-3">
           
                  <?php
                        if(is_active_sidebar('sidebar')):
                        dynamic_sidebar('sidebar');
                        endif;  
                  ?>
            </div>
      </div>
</div>
<?php get_footer(); ?>


