<!DOCTYPE html>
<html>

<head>
   <meta charset="<?php bloginfo('charset'); ?>">
   <!--displays the encoding-->
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
   <meta name="description" content="<?php bloginfo('description'); ?>">
   <!--displays the Tagline in Settings->General -->
   <title>
       <?php bloginfo('name'); ?>
   </title>
    <!-- Custom styles for this template -->
   <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,200;0,400;1,300&display=swap" rel="stylesheet">
 
   <?php wp_head(); ?>
</head>

<body>

   <nav class="navbar navbar-expand-md navbar-light text-white" role="navigation" style="background-color: #539DA8;">
 <div class="container">
   <!-- Brand and toggle get grouped for better mobile display -->
   <button class="navbar-toggler text-white" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-controls="bs-example-navbar-collapse-1" aria-expanded="false" aria-label="Toggle navigation" >
       <span class="navbar-toggler-icon text-white"></span>
   </button>
   <h1 class="navbar-brand m-0 pr-3" href="#" style="color: tomato; font-size:1.5rem;"><?php bloginfo('name'); ?></h1>
       <?php
       wp_nav_menu( array(
           'theme_location'    => 'primary',
           'depth'             => 2,
           'container'         => 'div',
           'container_class'   => 'collapse navbar-collapse',
           'container_id'      => 'bs-example-navbar-collapse-1',
           'menu_class'        => 'nav navbar-nav',
           'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
           'walker'            => new WP_Bootstrap_Navwalker(),
       ) );
       ?>
   </div>
</nav>