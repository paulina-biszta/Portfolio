<?php get_header(); ?>
   
<div class="container">
 

       <?php if(have_posts()) : ?> <!--  If there are posts available  -->

       <?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop
-->
       
           <h2 class="text-center p-5"><?php the_title(); ?> </h2>   <!--retrieves blog title-->
           <?php if(has_post_thumbnail()) : ?>
                     <?php the_post_thumbnail('medium_large'); ?>
                     <?php endif; ?>
                     <div class="row justify-content-between m-0 p-0">
                        <p>Created: <?php the_time('F j, Y g:i a'); ?></p><!--retrieves date blog entry was created-->
                        <p>Author: <?php the_author(); ?></p><!--retrieves author of blog entry-->
                     </div>
              <hr class="mt-3 mb-3" style="border-top: 3px solid tomato;">
              
              <?php the_content(); ?><!--retrieves content-->
              <hr class="mt-3 mb-3" style="border-top: 3px solid tomato;">
              <?php comments_template(); ?>

              <?php endwhile; ?><!--end the while loop-->

              <?php else :?> <!-- if no posts are found then: -->

              <p>No posts found</p>
              <?php endif; ?> <!-- end if -->

   </div>
 

 <?php get_footer(); ?>